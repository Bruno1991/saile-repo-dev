# -*- coding: utf-8 -*-
"""
Services package skeleton.
"""
